<!DOCTYPE html>
<html>
<head>
  <?php include '../html/Head.html'?>
</head>
<body>
  <?php include '../php/Menus.php' ?>
  <section class="main" id="s1">
    <div>
      Código PHP para mostrar una tabla con las preguntas de la BD.<br>
      La tabla incluye las imágenes de la BD.
    </div>
  </section>
  <?php include '../html/Footer.html' ?>
</body>
</html>
