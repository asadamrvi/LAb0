<!DOCTYPE html>
<html>
<head>
  <?php include '../html/Head.html'?>
</head>
<body>
  <?php include '../php/Menus.php' ?>
  <section class="main" id="s1">
    <div>

      <h2>Quiz: el juego de las preguntas</h2>
	  
      <a href="../php/QuestionForm.php"><h3> QuestionForm
	               </h3></a>
    </div>
  </section>
  <?php include '../html/Footer.html' ?>
</body>
</html>
