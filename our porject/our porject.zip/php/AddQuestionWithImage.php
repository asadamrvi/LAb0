<!DOCTYPE html>
<html>
<head>
  <?php include '../html/Head.html'?>
</head>
<body>
  <?php include '../php/Menus.php' ?>
  <section class="main" id="s1">
    <div>

			Código PHP para añadir una pregunta con imagen

    </div>
  </section>
  <?php include '../html/Footer.html' ?>
</body>
</html>
