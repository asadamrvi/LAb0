<div id='page-wrap'>
<header class='main' id='h1'>
  <span class="right"><a href="registro">Registro</a></span>
        <span class="right"><a href="login">Login</a></span>
        <span class="right" style="display:none;"><a href="/logout">Logout</a></span>

</header>
<nav class='main' id='n1' role='navigation'>
  <span><a href='Layout.php'>Inicio</a></span>
  <span><a href='QuestionForm.php'> Insertar Pregunta</a></span>
  <span><a href='Credits.php'>Creditos</a></span>
</nav>
