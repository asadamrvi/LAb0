
<!DOCTYPE html>
<html>

<head>
<script src="../js/jquery-3.4.1.min.js"></script>



  <?php include '../html/Head.html' ?>
</head>

<body>
  <?php include '../php/Menus.php' ?>



  <section class="main" id="s1">
      <div>

        <h2>Quiz: el juego de las preguntas</h2>
        



      </div>
  </section>

  <?php include '../html/Footer.html' ?>
</body>

</html>
