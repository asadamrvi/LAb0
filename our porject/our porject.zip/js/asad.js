
	$(document).ready(function(){
	
	$("#fEmail").focusout(function(){
		
		alert("text");
	}
	);
}
);