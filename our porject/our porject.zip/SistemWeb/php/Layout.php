<!DOCTYPE html>
<html>
<head>


  <?php include '../html/Head.html'?>
</head>
<body>
  <?php include '../php/Menus.php' ?>
  <section class="main" id="s1">
    <div>

      <h2>Quiz: el juego de las preguntas</h2>
	 
	  
      
    </div>
  </section>
  <?php include '../html/Footer.html' ?>
</body>
</html>


<?php


  if(isset($_GET['email']) && !empty($_GET['email'])){
    echo "email = ".$_GET['email'];
    //showMySpan();
  } 
  else {
    echo "";
  }

 
/*
function showMySpan() {

  var insertSpan = document.getElementById('insert');
  var viewSpan = document.getElementById('view');
  insertSpan.style.display = "block";
  viewSpan.style.display = "block";
}

*/

?>